import {readFile,writeFile,mkdir} from 'node:fs/promises';
const profile=JSON.parse(await readFile(new URL('../profile.json',import.meta.url),'utf8'));
const root=new URL('./',import.meta.url);
const base='https://perksy91.github.io/anam-hargey/';
const faq=[
['How do I start looking at Glenview homes for sale?', 'Start with your budget, move date and the rooms you actually need. Send Anam those details before booking tours. Pick a few addresses to compare, then visit at the times you would normally commute or run errands.'],
['I want to sell my home in Glenview. What comes first?', 'Ask Anam to review recent comparable sales and walk through your home before spending on improvements. Discuss timing, repairs and photography together. If you are buying too, talk through the order of both moves before setting a listing date.'],
['What should I compare in North Shore new construction?', 'Compare the floor plan, lot, included finishes and the written list of upgrades. Ask about delivery dates and what happens if construction runs late. Bring the builder’s specifications to Anam so you can discuss the choices before committing.'],
['Can Anam help with Northbrook and Deerfield real estate?', 'Yes. Anam works in Glenview and Chicago’s North Shore, including Northbrook and Deerfield. Share the locations you are considering, your budget and your timeline. That gives the conversation a useful starting point, whether you are buying or selling.']
];
const agent={'@context':'https://schema.org','@type':'RealEstateAgent','@id':base+'#anam',name:profile.name,telephone:'+18472748309',email:profile.email,url:base,image:base+'img/headshot.jpg',areaServed:[...profile.areas,"Chicago's North Shore"].map(name=>({'@type':'Place',name})),knowsLanguage:profile.languages,memberOf:profile.affiliations.map(name=>({'@type':'Organization',name})),parentOrganization:{'@type':'Organization',name:'SERHANT.',url:'https://serhant.com/'},sameAs:[profile.instagram,profile.brokerage_profile]};
const schema={'@context':'https://schema.org','@type':'FAQPage',mainEntity:faq.map(([name,text])=>({'@type':'Question',name,acceptedAnswer:{'@type':'Answer',text}}))};
const html=`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Glenview Realtor &amp; North Shore Homes | Anam Hargey | SERHANT.</title>
<meta name="description" content="Meet Anam Hargey, a Glenview realtor and North Shore real estate agent at SERHANT. Talk about buying, selling or new construction across Chicago's North Shore.">
<!-- PREVIEW: remove at go-live after Anam approves -->
<meta name="robots" content="noindex">
<link rel="canonical" href="${base}">
<meta property="og:type" content="website"><meta property="og:locale" content="en_US">
<meta property="og:title" content="Glenview and North Shore Homes with Anam Hargey">
<meta property="og:description" content="Buying, selling and new construction in Glenview and Chicago's North Shore. Anam Hargey, Licensed Real Estate Broker at SERHANT.">
<meta property="og:url" content="${base}"><meta property="og:image" content="${base}img/og.jpg">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Anam Hargey, Glenview and Chicago's North Shore homes, SERHANT.">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="Glenview and North Shore Homes with Anam Hargey">
<meta name="twitter:description" content="Talk with Anam Hargey about buying, selling and new construction on Chicago's North Shore.">
<meta name="twitter:image" content="${base}img/og.jpg"><meta name="twitter:image:alt" content="Anam Hargey, Glenview and Chicago's North Shore homes, SERHANT.">
<link rel="icon" href="img/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="styles.css">
<link rel="preload" href="fonts/montserrat.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="fonts/inter.woff2" as="font" type="font/woff2" crossorigin>
<script type="application/ld+json">${JSON.stringify(agent)}</script>
<script type="application/ld+json">${JSON.stringify(schema)}</script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="masthead wrap">
<a class="identity" href="#home" aria-label="Anam Hargey home">ANAM HARGEY<span>GLENVIEW &amp; CHICAGO'S NORTH SHORE</span></a>
<nav aria-label="Main navigation"><a href="#about">About</a><a href="#guide">Local guide</a><a href="#contact">Get in touch <span aria-hidden="true">↗</span></a></nav>
</header>
<main id="main">
<section id="home" class="hero wrap" aria-labelledby="hero-title">
<div class="hero-grid"><div class="hero-copy"><p class="label">Licensed Real Estate Broker · SERHANT.</p>
<h1 id="hero-title">Glenview and North Shore Homes with Anam Hargey</h1>
<p class="intro">Talk with Anam about buying, selling or planning a family move in Glenview and Chicago's North Shore.</p>
<div class="buttons"><a class="button solid" href="tel:+18472748309">Call Anam <span aria-hidden="true">↗</span></a><a class="button outline" href="mailto:anam@serhant.com">Email Anam <span aria-hidden="true">↗</span></a></div>
</div><figure class="portrait"><img src="img/headshot.jpg" alt="Anam Hargey, Licensed Real Estate Broker at SERHANT." width="1179" height="1179" fetchpriority="high"><figcaption>Anam Hargey <span>Glenview, Illinois</span></figcaption></figure></div>
<div class="claims" aria-label="Agent-supplied credentials awaiting confirmation">${profile.claims.map(c=>`<p class="claim">${c}<!-- CLAIM: confirm with Anam before publishing --></p>`).join('')}</div>
</section>
<section id="about" class="wrap section about" aria-labelledby="about-title"><div class="section-side"><p class="section-number">01 / MEET ANAM</p><img class="about-photo" src="img/headshot.jpg" alt="Portrait of Anam Hargey" width="1179" height="1179" loading="lazy" decoding="async"></div><div><h2 id="about-title">About Anam</h2>
<p>Anam lives in Glenview and leads The Hargey Group. Before real estate, she was a Licensed Clinical Professional Counselor (LCPC), with a master's in clinical counseling and experience in marriage and family counseling. She closed her first deal in September 2020 and joined SERHANT. in October 2026.</p>
<p>Raised in a family of luxury developers, she brings a background in home design and new construction to conversations about a move. She is involved with a Glenview school parent-teacher organization (PTO) and speaks English. She also helps with homes across Chicago.</p>
<blockquote>“Kindness is spreading sunshine into other people's lives regardless of the weather.”</blockquote>
</div></section>
<section id="reasons" class="reasons" aria-labelledby="reasons-title"><div class="wrap"><p class="section-number">02 / BUYING &amp; SELLING</p><h2 id="reasons-title">Three reasons to work<br class="desktop-break"> with a homes specialist</h2><div class="reason-grid">
<article><span class="large-number" aria-hidden="true">01</span><h3>Plan the family move</h3><p>Agree on your move date, budget and must-haves before touring. A counselor's background can help keep those conversations focused when family members want different things.</p></article>
<article><span class="large-number" aria-hidden="true">02</span><h3>Read beyond the finishes</h3><p>For a new build, compare room dimensions, allowances and upgrade costs. A beautiful kitchen is only one part of deciding whether a home fits your plans.</p></article>
<article><span class="large-number" aria-hidden="true">03</span><h3>Prepare before you list</h3><p>Review comparable sales before choosing a price. Walk through repairs and photography with your agent, so you can decide where preparation time and money should go.</p></article>
</div></div></section>
<section id="guide" class="wrap section guide" aria-labelledby="guide-title"><div class="section-side"><p class="section-number">03 / THE LOCAL GUIDE</p><p class="guide-location">Glenview,<br>Illinois</p></div><div><h2 id="guide-title">Glenview and Chicago's<br class="desktop-break"> North Shore guide</h2>
<p>Get to know Glenview beyond a listing address. The Glen in Glenview grew from the former Naval Air Station after the base closed in 1995. The <a href="https://www.glenview.il.us/610/Glenview-History">Village's history</a> explains that change.</p>
<p>At 1421 Milwaukee Avenue in Glenview, <a href="https://glenviewparks.org/facilities/the-grove/">The Grove</a> preserves 150 acres, with trails through oak-hickory savanna and past wetland pools. It was designated a National Historic Landmark in 1976.</p>
<p>Before choosing a home, look up the exact address in <a href="https://register.glenview34.org/boundary-search">District 34's school boundary search</a>. The district recommends confirming boundaries with the relevant township before buying or signing a lease. Use those resources to plan your visits, then talk with Anam about the addresses on your shortlist.</p>
<!-- LISTING PHOTO SLOT 1: Insert Anam's own approved listing photo here, with address, rights confirmation, width, height and lazy loading. No stock or AI imagery. -->
<!-- LISTING PHOTO SLOT 2: Reserved for a second approved listing photo. Do not imply that an unavailable property is an active listing. -->
</div></section>
<section id="faq" class="wrap section faq" aria-labelledby="faq-title"><div class="section-side"><p class="section-number">04 / YOUR QUESTIONS</p><h2 id="faq-title">Before<br class="desktop-break"> you move</h2></div><div class="faq-list">${faq.map(([q,a])=>`<article><h3>${q}</h3><p>${a}</p></article>`).join('')}</div></section>
<section id="contact" class="contact" aria-labelledby="contact-title"><div class="wrap contact-grid"><div><p class="section-number">05 / CONTACT ANAM</p><h2 id="contact-title">Talk through<br>your move.</h2><p>Homes across Chicago's North Shore</p></div><div class="contact-links"><a href="tel:+18472748309">847.274.8309 <span aria-hidden="true">↗</span></a><a href="mailto:anam@serhant.com">anam@serhant.com <span aria-hidden="true">↗</span></a><div class="social"><a href="https://www.instagram.com/anamhargey.realtor/">Instagram ↗</a><span>LinkedIn · link coming soon</span><!-- CONFIRM: Anam's LinkedIn URL is empty in profile.json. Replace this text with her supplied URL before go-live. --></div></div></div></section>
</main>
<footer class="wrap footer"><div><img src="img/logo-serhant.svg" alt="SERHANT." width="158" height="26" loading="lazy"><p>Sponsoring brokerage · <a href="tel:+16464807665">646.480.7665</a><!-- CONFIRM: Illinois office phone --></p></div><div><p>Equal Housing Opportunity. We welcome buyers and sellers<br class="desktop-break"> without discrimination under fair housing laws.</p><p>© 2026 Anam Hargey · SERHANT.</p></div></footer>
</body></html>`;
await writeFile(new URL('index.html',root),html);
await writeFile(new URL('img/favicon.svg',root),'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="8" fill="#001A72"/><text x="32" y="42" text-anchor="middle" font-family="Arial,sans-serif" font-weight="600" font-size="29" fill="#FFFFFF">AH</text></svg>');
await writeFile(new URL('robots.txt',root),`User-agent: *\nAllow: /\nDisallow: /_check/\nSitemap: ${base}sitemap.xml\n`);
await writeFile(new URL('sitemap.xml',root),`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${base}</loc></url></urlset>\n`);
await mkdir(new URL('fonts/',root),{recursive:true});
for(const [family,file] of [['Montserrat','montserrat'],['Inter','inter']]){
 const url=`https://fonts.googleapis.com/css2?family=${family}:wght@400..700&display=swap`;
 const css=await (await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'}})).text();
 const blocks=css.split('/* latin */');
 const fontUrl=(blocks.at(-1).match(/url\((https:[^)]+)\)/)||[])[1];
 if(!fontUrl) throw new Error('No font URL for '+family);
 const font=await fetch(fontUrl); if(!font.ok)throw new Error('Font request failed');
 await writeFile(new URL(`fonts/${file}.woff2`,root),Buffer.from(await font.arrayBuffer()));
}
console.log('Built static page and downloaded local font files.');
